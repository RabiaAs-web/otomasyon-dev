﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FireSharp.Response;

namespace otomasyon4
{
    public partial class FormEtkinlikEkle : Form
    {
        public FormEtkinlikEkle()
        {
            InitializeComponent();
        }

        private void btnKaydet_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtAd.Text) ||
                 string.IsNullOrWhiteSpace(txtYer.Text))
            {
                MessageBox.Show("Lütfen tüm alanları doldurun");
                return;
            }
            Etkinlik etkinlik = new Etkinlik
            {
                Ad = txtAd.Text,
                Yer = txtYer.Text,
                Tarih = dtTarih.Value
            };

            FirebaseResponse response =
                FirebaseBaglanti.Client.Push("etkinlikler", etkinlik);

            MessageBox.Show("Etkinlik Firebase'e kaydedildi ✅");

            txtAd.Clear();
            txtYer.Clear();
            dtTarih.Value = DateTime.Now;
        }
    }
}
