﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace otomasyon4
{
    internal class EtkinlikKatilimci
    {
        public string EtkinlikId { get; set; }
        public string KatilimciId { get; set; }
    }
}
