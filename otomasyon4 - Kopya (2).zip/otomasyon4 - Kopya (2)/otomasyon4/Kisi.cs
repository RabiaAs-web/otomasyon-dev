﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace otomasyon4
{
    public abstract class Kisi : BaseEntity
    {
        public string AdSoyad { get; set; }

        public abstract string BilgiGetir();
    }
}
