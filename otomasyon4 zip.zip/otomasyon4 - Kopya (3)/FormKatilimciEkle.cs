﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FireSharp.Response;

namespace otomasyon4
{
    public partial class FormKatilimciEkle : Form
    {
        public FormKatilimciEkle()
        {
            InitializeComponent();
        }
        private void btnKaydet_Click(object sender, System.EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtAdSoyad.Text) ||
                string.IsNullOrWhiteSpace(txtTelefon.Text))
            {
                MessageBox.Show("Lütfen tüm alanları doldurun");
                return;
            }

            Katilimci katilimci = new Katilimci
            {
                AdSoyad = txtAdSoyad.Text,
                Telefon = txtTelefon.Text
            };

            FirebaseResponse response =
                FirebaseBaglanti.Client.Push("katilimcilar", katilimci);

            MessageBox.Show("Katılımcı Firebase'e kaydedildi ✅");

            txtAdSoyad.Clear();
            txtTelefon.Clear();
        }

    }
    }

