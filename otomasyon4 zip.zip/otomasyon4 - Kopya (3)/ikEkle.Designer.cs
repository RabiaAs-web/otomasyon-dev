﻿namespace otomasyon4
{
    partial class FormEtkinlikEkle
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Button btnKaydet;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtAd;
        private System.Windows.Forms.TextBox txtYer;
        private System.Windows.Forms.DateTimePicker dtTarih;
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtAd = new System.Windows.Forms.TextBox();
            this.txtYer = new System.Windows.Forms.TextBox();
            this.dtTarih = new System.Windows.Forms.DateTimePicker();
            this.btnKaydet = new System.Windows.Forms.Button();
            this.SuspendLayout();
            
            this.label1.Location = new System.Drawing.Point(20, 20);
            this.label1.Text = "Etkinlik Adı";
            this.txtAd.Location = new System.Drawing.Point(120, 20);
            
            this.label2.Location = new System.Drawing.Point(20, 60);
            this.label2.Text = "Etkinlik Yeri";
            this.txtYer.Location = new System.Drawing.Point(120, 60);
           
            this.label3.Location = new System.Drawing.Point(20, 100);
            this.label3.Text = "Etkinlik Tarihi";
            this.dtTarih.Location = new System.Drawing.Point(120, 100);
           
            this.btnKaydet.Location = new System.Drawing.Point(120, 140);
            this.btnKaydet.Text = "Kaydet";
            this.btnKaydet.Click += new System.EventHandler(this.btnKaydet_Click);

            
            this.ClientSize = new System.Drawing.Size(320, 200);
            this.Controls.AddRange(new System.Windows.Forms.Control[] {
                label1, txtAd, label2, txtYer, label3, dtTarih, btnKaydet
            });
            this.Text = "Etkinlik Ekle";
            this.ResumeLayout(false);
            this.PerformLayout();
        }
        

        
    }
}