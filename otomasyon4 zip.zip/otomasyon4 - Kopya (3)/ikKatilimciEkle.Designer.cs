﻿namespace otomasyon4
{
    partial class FormEtkinlikKatilimciEkle
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

       

        private void InitializeComponent()
        {
            this.cmbEtkinlik = new System.Windows.Forms.ComboBox();
            this.cmbKatilimci = new System.Windows.Forms.ComboBox();
            this.btnKaydet = new System.Windows.Forms.Button();
            this.SuspendLayout();
            
            this.cmbEtkinlik.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEtkinlik.FormattingEnabled = true;
            this.cmbEtkinlik.Location = new System.Drawing.Point(40, 30);
            this.cmbEtkinlik.Name = "cmbEtkinlik";
            this.cmbEtkinlik.Size = new System.Drawing.Size(260, 23);
            this.cmbEtkinlik.TabIndex = 0;
           
            
           
            this.cmbKatilimci.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbKatilimci.FormattingEnabled = true;
            this.cmbKatilimci.Location = new System.Drawing.Point(40, 70);
            this.cmbKatilimci.Name = "cmbKatilimci";
            this.cmbKatilimci.Size = new System.Drawing.Size(260, 23);
            this.cmbKatilimci.TabIndex = 1;
            
            this.btnKaydet.Location = new System.Drawing.Point(40, 115);
            this.btnKaydet.Name = "btnKaydet";
            this.btnKaydet.Size = new System.Drawing.Size(260, 35);
            this.btnKaydet.TabIndex = 2;
            this.btnKaydet.Text = "Katılımcıyı Etkinliğe Ata";
            this.btnKaydet.UseVisualStyleBackColor = true;
            this.btnKaydet.Click += new System.EventHandler(this.btnKaydet_Click);
            
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(350, 190);
            this.Controls.Add(this.btnKaydet);
            this.Controls.Add(this.cmbKatilimci);
            this.Controls.Add(this.cmbEtkinlik);
            this.Name = "FormEtkinlikKatilimciEkle";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Etkinliğe Katılımcı Ata";
            this.Load += new System.EventHandler(this.FormEtkinlikKatilimciEkle_Load);
            this.ResumeLayout(false);
        }

        

        private System.Windows.Forms.ComboBox cmbEtkinlik;
        private System.Windows.Forms.ComboBox cmbKatilimci;
        private System.Windows.Forms.Button btnKaydet;
    }
}