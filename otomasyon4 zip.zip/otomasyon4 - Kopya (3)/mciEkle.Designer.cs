﻿namespace otomasyon4
{
    partial class FormKatilimciEkle
    {

        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtAdSoyad;
        private System.Windows.Forms.TextBox txtTelefon;
        private System.Windows.Forms.Button btnKaydet;


        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtAdSoyad = new System.Windows.Forms.TextBox();
            this.txtTelefon = new System.Windows.Forms.TextBox();
            this.btnKaydet = new System.Windows.Forms.Button();
            this.SuspendLayout();
            
            this.label1.Location = new System.Drawing.Point(20, 20);
            this.label1.Text = "Ad Soyad";
            this.txtAdSoyad.Location = new System.Drawing.Point(120, 20);
            
            this.label2.Location = new System.Drawing.Point(20, 60);
            this.label2.Text = "Telefon";
            this.txtTelefon.Location = new System.Drawing.Point(120, 60);
            
            this.btnKaydet.Location = new System.Drawing.Point(120, 100);
            this.btnKaydet.Text = "Kaydet";
            this.btnKaydet.Click += new System.EventHandler(this.btnKaydet_Click);
            
            this.ClientSize = new System.Drawing.Size(300, 160);
            this.Controls.AddRange(new System.Windows.Forms.Control[] {
                label1, txtAdSoyad, label2, txtTelefon, btnKaydet
            });
            this.Text = "Katılımcı Ekle";
            this.ResumeLayout(false);
            this.PerformLayout();




        }
    }
}