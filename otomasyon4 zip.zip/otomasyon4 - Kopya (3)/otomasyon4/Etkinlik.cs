﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace otomasyon4
{
    public class Etkinlik : BaseEntity
    {
        public string FirebaseKey { get; set; }

        public string Ad { get; set; }
        public string Yer { get; set; }
        public DateTime Tarih { get; set; }

       
    }
}
