﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace otomasyon4
{
    public class EtkinlikYonetici
    {
        public static List<Etkinlik> Etkinlikler = new List<Etkinlik>();
        public static List<Katilimci> Katilimcilar = new List<Katilimci>();
    }
}
