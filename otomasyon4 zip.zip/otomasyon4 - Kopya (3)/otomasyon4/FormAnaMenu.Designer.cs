﻿namespace otomasyon4
{
    partial class FormAnaMenu
    {

        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Button btnEtkinlikEkle;
        private System.Windows.Forms.Button btnEtkinlikListele;
        private System.Windows.Forms.Button btnCikis;
        private System.Windows.Forms.Button btnKtilimciEkle;
        private System.Windows.Forms.Button btnKatilimciListele;
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

   

        private void InitializeComponent()
        {
            this.btnEtkinlikEkle = new System.Windows.Forms.Button();
            this.btnEtkinlikListele = new System.Windows.Forms.Button();
            this.btnKtilimciEkle = new System.Windows.Forms.Button();
            this.btnCikis = new System.Windows.Forms.Button();
            this.btnKatilimciListele = new System.Windows.Forms.Button();
            this.btnEtkinlikKatilimciAta = new System.Windows.Forms.Button();
            this.SuspendLayout();
            
            
            this.btnEtkinlikEkle.Location = new System.Drawing.Point(60, 30);
            this.btnEtkinlikEkle.Name = "btnEtkinlikEkle";
            this.btnEtkinlikEkle.Size = new System.Drawing.Size(150, 30);
            this.btnEtkinlikEkle.TabIndex = 0;
            this.btnEtkinlikEkle.Text = "Etkinlik Ekle";
            this.btnEtkinlikEkle.UseVisualStyleBackColor = true;
            this.btnEtkinlikEkle.Click += new System.EventHandler(this.btnEtkinlikEkle_Click);
            
            this.btnEtkinlikListele.Location = new System.Drawing.Point(60, 70);
            this.btnEtkinlikListele.Name = "btnEtkinlikListele";
            this.btnEtkinlikListele.Size = new System.Drawing.Size(150, 30);
            this.btnEtkinlikListele.TabIndex = 1;
            this.btnEtkinlikListele.Text = "Etkinlik Listele";
            this.btnEtkinlikListele.UseVisualStyleBackColor = true;
            this.btnEtkinlikListele.Click += new System.EventHandler(this.btnEtkinlikListele_Click);
          
            this.btnKtilimciEkle.Location = new System.Drawing.Point(60, 110);
            this.btnKtilimciEkle.Name = "btnKtilimciEkle";
            this.btnKtilimciEkle.Size = new System.Drawing.Size(150, 30);
            this.btnKtilimciEkle.TabIndex = 2;
            this.btnKtilimciEkle.Text = "Katılımcı Ekle";
            this.btnKtilimciEkle.UseVisualStyleBackColor = true;
            this.btnKtilimciEkle.Click += new System.EventHandler(this.btnKtilimciEkle_Click);
          
            this.btnCikis.Location = new System.Drawing.Point(60, 253);
            this.btnCikis.Name = "btnCikis";
            this.btnCikis.Size = new System.Drawing.Size(150, 30);
            this.btnCikis.TabIndex = 3;
            this.btnCikis.Text = "Çıkış";
            this.btnCikis.UseVisualStyleBackColor = true;
            this.btnCikis.Click += new System.EventHandler(this.btnCikis_Click);
        
            this.btnKatilimciListele.Location = new System.Drawing.Point(60, 155);
            this.btnKatilimciListele.Name = "btnKatilimciListele";
            this.btnKatilimciListele.Size = new System.Drawing.Size(150, 32);
            this.btnKatilimciListele.TabIndex = 4;
            this.btnKatilimciListele.Text = "Katlımcı Listele";
            this.btnKatilimciListele.UseVisualStyleBackColor = true;
            this.btnKatilimciListele.Click += new System.EventHandler(this.btnKatilimciListele_Click_1);
            
            this.btnEtkinlikKatilimciAta.Location = new System.Drawing.Point(60, 205);
            this.btnEtkinlikKatilimciAta.Name = "btnEtkinlikKatilimciAta";
            this.btnEtkinlikKatilimciAta.Size = new System.Drawing.Size(150, 31);
            this.btnEtkinlikKatilimciAta.TabIndex = 5;
            this.btnEtkinlikKatilimciAta.Text = "Ekinliğe Katılımcı Ata";
            this.btnEtkinlikKatilimciAta.UseVisualStyleBackColor = true;
            this.btnEtkinlikKatilimciAta.Click += new System.EventHandler(this.btnEtkinlikKatilimciAta_Click);
         
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(342, 347);
            this.Controls.Add(this.btnEtkinlikKatilimciAta);
            this.Controls.Add(this.btnKatilimciListele);
            this.Controls.Add(this.btnCikis);
            this.Controls.Add(this.btnKtilimciEkle);
            this.Controls.Add(this.btnEtkinlikListele);
            this.Controls.Add(this.btnEtkinlikEkle);
            this.MaximizeBox = false;
            this.Name = "FormAnaMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ana Menü";
            this.ResumeLayout(false);

        }

        private System.Windows.Forms.Button btnEtkinlikKatilimciAta;
    }
}