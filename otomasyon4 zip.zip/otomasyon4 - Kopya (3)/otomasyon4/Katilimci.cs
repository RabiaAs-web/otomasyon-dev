﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace otomasyon4
{
    public class Katilimci : Kisi
    {
      public string FirebaseKey { get; set; }
        public string Telefon { get; set; }

        public override string BilgiGetir()
        {
            return $" {AdSoyad} -  {Telefon}";
        }
    }
}
