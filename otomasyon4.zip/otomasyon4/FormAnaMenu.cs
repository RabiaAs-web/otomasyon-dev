﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace otomasyon4
{
    public partial class FormAnaMenu : Form
    {
        public FormAnaMenu()
        {
            InitializeComponent();
        }

        private void btnEtkinlikEkle_Click(object sender, EventArgs e)
        {
            FormEtkinlikEkle frm = new FormEtkinlikEkle();
            frm.ShowDialog();
        }

        private void btnEtkinlikListele_Click(object sender, EventArgs e)
        {
            FormEtkinlikListele frm = new FormEtkinlikListele();
            frm.ShowDialog();
        }

        private void btnKtilimciEkle_Click(object sender, EventArgs e)
        {
            FormKatilimciEkle frm = new FormKatilimciEkle();
            frm.ShowDialog();
        }
      
        

        private void btnCikis_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnKatilimciListele_Click_1(object sender, EventArgs e)
        {
            FormKatilimciListele frm = new FormKatilimciListele();
            frm.ShowDialog();
        }

        private void btnEtkinlikKatilimciAta_Click(object sender, EventArgs e)
        {
            FormEtkinlikKatilimciEkle frm = new FormEtkinlikKatilimciEkle();
            frm.Show();
        }
    }
}
