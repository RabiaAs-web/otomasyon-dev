﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FireSharp.Response;

namespace otomasyon4
{
    public partial class FormEtkinlikKatilimciEkle : Form
    {

        public FormEtkinlikKatilimciEkle()
        {
            InitializeComponent();
        }

        private void btnKaydet_Click(object sender, EventArgs e)
        {
            if (cmbEtkinlik.SelectedItem == null ||
                cmbKatilimci.SelectedItem == null)
            {
                MessageBox.Show("Lütfen seçim yapın");
                return;
            }

            EtkinlikKatilimci ek = new EtkinlikKatilimci
            {
                EtkinlikId = cmbEtkinlik.SelectedValue.ToString(),
                KatilimciId = cmbKatilimci.SelectedValue.ToString()
            };

            FirebaseBaglanti.Client
                .Push("etkinlikKatilimcilari", ek);

            MessageBox.Show("Katılımcı etkinliğe atandı");
        }

        private void FormEtkinlikKatilimciEkle_Load(object sender, EventArgs e)
        {
            var etkResponse = FirebaseBaglanti.Client.Get("etkinlikler");

            if (etkResponse.Body != "null")
            {
                var etkinlikler =
                    etkResponse.ResultAs<Dictionary<string, Etkinlik>>();

                
        cmbEtkinlik.DataSource = etkinlikler
            .Select(x => new { Id = x.Key, Ad = x.Value.Ad })
            .ToList();

                cmbEtkinlik.DisplayMember = "Ad";
                cmbEtkinlik.ValueMember = "Id";


            }

            
            var katResponse = FirebaseBaglanti.Client.Get("katilimcilar");

            if (katResponse.Body != "null")
            {
                var katilimcilar =
                    katResponse.ResultAs<Dictionary<string, Katilimci>>();

                cmbKatilimci.DataSource = katilimcilar
             .Select(x => new { Id = x.Key, Ad = x.Value.AdSoyad })
             .ToList();

                cmbKatilimci.DisplayMember = "Ad";
                cmbKatilimci.ValueMember = "Id";
            }
        }
        }
    }


