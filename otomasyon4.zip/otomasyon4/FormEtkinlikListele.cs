﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FireSharp.Response;

namespace otomasyon4
{
    public partial class FormEtkinlikListele : Form
    {
        public FormEtkinlikListele()
        {
            InitializeComponent();
        }

        private void btnYenile_Click(object sender, EventArgs e)
        {
            FirebaseResponse response =
                 FirebaseBaglanti.Client.Get("etkinlikler");

            if (response.Body == "null")
            {
                MessageBox.Show("Kayıtlı etkinlik bulunamadı");
                return;
            }

            Dictionary<string, Etkinlik> etkinlikler =
                response.ResultAs<Dictionary<string, Etkinlik>>();

            List<Etkinlik> liste = new List<Etkinlik>();

            foreach (var item in etkinlikler)
            {
                Etkinlik etkinlik = item.Value;
                etkinlik.FirebaseKey = item.Key;   
                liste.Add(etkinlik);
            
        }

            dataGridView1.DataSource = null;
            dataGridView1.DataSource = liste;
        }

        private void btnSil_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
            {
                MessageBox.Show("Lütfen silinecek etkinliği seçin");
                return;
            }

            Etkinlik secili =
                (Etkinlik)dataGridView1.CurrentRow.DataBoundItem;

            DialogResult sonuc = MessageBox.Show(secili.Ad + " silinsin mi?", "Onay", MessageBoxButtons.YesNo);

            if (sonuc == DialogResult.Yes)
            {
                FirebaseBaglanti.Client
                    .Delete("etkinlikler/" + secili.FirebaseKey);

                MessageBox.Show("Etkinlik silindi");
                btnYenile_Click(null, null);
            }
        }
    }
}
