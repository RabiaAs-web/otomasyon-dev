﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FireSharp.Response;

namespace otomasyon4
{
    public partial class FormKatilimciListele : Form
    {
        public FormKatilimciListele()
        {
            InitializeComponent();

        }
        private void btnKatilimciListele_Click(object sender, EventArgs e)
        {
            try { FirebaseResponse response = FirebaseBaglanti.Client.Get("katilimcilar");
                if (response.Body == "null") 
                {
                    MessageBox.Show("Kayıtlı katılımcı bulunamadı");
                    return;
                }
                Dictionary<string, Katilimci> katilimcilar = response.ResultAs<Dictionary<string, Katilimci>>();
                List<Katilimci> liste = new List<Katilimci>();
                foreach (var item in katilimcilar)
                {
                    Katilimci k = item.Value;
                    k.FirebaseKey = item.Key;   
                    liste.Add(k);
                }
                dataGridView1.DataSource = null;
                dataGridView1.DataSource = liste;
            }
            catch (Exception ex) 
            {
                MessageBox.Show("Hata oluştu: " + ex.Message);
            }
        }
        private void btnSil_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Lütfen silinecek katılımcıyı seçin");
                return; 
            }
            Katilimci secili = (Katilimci)dataGridView1.SelectedRows[0].DataBoundItem;
            DialogResult sonuc = MessageBox.Show(secili.AdSoyad + " silinsin mi?", "Onay", MessageBoxButtons.YesNo);
            if (sonuc == DialogResult.Yes)
            {
                FirebaseBaglanti.Client.Delete("katilimcilar/" + secili.FirebaseKey);
                MessageBox.Show("Katılımcı silindi");
                btnKatilimciListele_Click(null,null);
            }
        }
    }
}

