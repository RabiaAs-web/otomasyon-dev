﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FireSharp.Config;
using FireSharp.Interfaces;

namespace otomasyon4
{
    public  class FirebaseBaglanti
    {
        public static IFirebaseClient Client;

        public static void Baglan()
        {
            IFirebaseConfig config = new FirebaseConfig
            {
                BasePath = "https://otomasyon4-d5c62-default-rtdb.firebaseio.com/",
                AuthSecret = "KKKoRHBZcpPEEHZDhYDz3AyUcQ2LBFyLcm6TDia0"
            };

            Client = new FireSharp.FirebaseClient(config);
           
        }
    }
    }

